# Ashmem linux kernel module

Out of tree linux kernel module for ashmem
